---
title: oh my zsh~
date: 2019-04-16 15:04:28
tags:
---
## 1. zsh 是什么
 > Z Shell(Zsh) 是一种Unix shell，它可以用作为交互式的登录shell，也是一种强大的shell脚本命令解释器
 ---
 > 官网：https://ohmyz.sh/


## 2，zsh 的安装与使用
执行：sudo yum update && sudo yum -y install zsh进行安装zsh，安装成功后，键入 zsh --version 查看是否安装成功。
    
zsh 安装成功之后，我们就可以将默认的 shell 切换至 zsh，在做这个操作之前，我们可以确认一下已经安装好的 shell 脚本有哪些：cat /etc/shells。
切换默认的 shell 至 zsh:chsh -s $(which zsh)
                                    
## 3，oh my zsh
安装好 zsh 之后，他还并不像我们前面所描述的那样这么强大，我们还需要一个很酷的工具 Oh My Zsh 来管理和扩展我们的 zsh  
安装:
```bash
1、git clone https://github.com/robbyrussell/oh-my-zsh.git ~/.oh-my-zsh
2、cp ~/.zshrc ~/.zshrc.orig
3、cp ~/.oh-my-zsh/templates/zshrc.zsh-template ~/.zshrc
4、chsh -s /bin/zsh
```
安装成功后，重新打开一个新的终端，如果发现界面主题已经改变，代表安装成功配置已经生效了。
## 4,快捷键
    option+space快速打开                                  


