---
title: css中的BFC
date: 2019-03-12 14:40:15
---

Formatting context(格式化上下文) 是 W3C CSS2.1 规范中的一个概念。它是页面中的一块渲染区域，并且有一套渲染规则，它决定了其子元素将如何定位，以及和其他元素的关系和相互作用。

BFC 即 Block Formatting Contexts (块级格式化上下文)，它属于上述定位方案的普通流。

具有 BFC 特性的元素可以看作是隔离了的独立容器，容器里面的元素不会在布局上影响到外面的元素，并且 BFC 具有普通容器所没有的一些特性。

<!--more-->

## 1. 触发 BFC
只要元素满足下面任一条件即可触发 BFC 特性：

<ol>
    <li>body 根元素</li>
    <li>浮动元素：float 除 none 以外的值</li>
    <li>绝对定位元素：position (absolute、fixed)</li>
    <li>display 为 inline-block、table-cells、flex</li>
    <li>overflow 除了 visible 以外的值 (hidden、auto、scroll)</li>
</ol>

## 2. BFC 特性及应用
<ol>
    <li>
        <b>同一个 BFC 下外边距会发生折叠</b></br>
        <p>如果想要避免外边距的重叠，可以将其放在不同的 BFC 容器中</p>
    </li>
    <li>
        <b>BFC 可以包含浮动的元素（清除浮动）</b>
        <p>使得浮动元素也能撑起父元素的高度</p>
    </li>
    <li>
        <b>BFC 可以阻止元素被浮动元素覆盖</b><br>
        <p>这个方法可以用来实现两列自适应布局，效果不错，这时候左边的宽度固定，右边的内容自适应宽度</p>
    </li>
</ol>


