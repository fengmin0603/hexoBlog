---
title: vuejs介绍
date: 2018-09-07 20:24:02
tags:
---
近年来前端开发趋势
* 旧浏览器逐渐淘汰，移动端需求增加。IE6-IE8不支持ES5特性的Object.defineproperty这个属性。
而IE9+/chrome/safari/firefox都是支持ES5特性的，而移动端的大部分内核都是基于webkit的，因此vuejs可以大范围的使用在移动端浏览器和一些高端浏览器
* 前端交互越来越多，功能越来越复杂
    <ol>
        <li>酷炫的运营活动页面</li>
        <li>高大上的技术库和框架</li>
        <li>H5小游戏</li>
        <li>社交网络</li>
        <li>在线购物平台</li>
        <li>新闻趣味站</li>
        <li>金融信贷应用</li>
        <li>音乐互动社区</li>
        <li>视频分享平台</li>
        <li>打车出行平台</li>
        <li>等等</li>
    </ol>
* 架构从传统后台MVC向REST API+前端MVVM迁移

<!--more-->

## MVVM框架
* 基本概念
![avatar](mvvm.png)
    如上图所示，MVVM框架主要有三个部分。【Model】是数据部分，对应前端的javascript对象；【View】是视图部分，对应前端的dom；【ViewModel】就是连接视图和数据的中间件。在MVVM架构下，【View】和【Model】是不能直接通讯的，通常会通过【ViewModel】来进行通讯，【ViewModel】通常会实现一个observer观察者，当数据【Model】发生变化，【ViewModel】可以观察到数据的这种变化，然后通知到对应的的视图【View】做更新；而当用户操作视图【View】，【ViewModel】也能监听到视图的变化，然后通知【Model】的数据做改动，这样，就实现了双向数据绑定。
* 应用场景
<ol>
<li>针对具有复杂交互逻辑的前端应用</li>
<li>提供基础的架构抽象</li>
<li>通过ajax做数据持久化，保证前端用户体验</li>
</ol>

## 简单介绍下vuejs
* 一个轻量级MVVM框架
* 数据驱动+组件化的前端开发，数据驱动+组件化是vuejs的核心思想
* GitHub的star数多，社区完善

## 如何做技术选型
* 看社区如何
     同样是前端MVVM框架，vue和angular的社区都很棒。但对比angular,vuejs更加轻量，gzip后大小只有26k，而angular进行gzip后大小大约是56k，react进行gzip后的大小大概是44k。所以，对于移动端来说，vuejs更加合适
* vuejs更易上手，学习曲线更加平稳，官网文档比较完善
* vuejs吸取了angular的指令和react的组件化

## vuejs两大核心思想
* 数据驱动
    - DOM是数据的一种自然映射
    ![avatar](mvvm2.png)
    如上图所示的mvvm示意图，vue实例是一个ViewModel。传统的没有ViewModel层，会从后台获取数据，并手动的修改DOM节点，这种方式复杂、耗性能且不易维护，使用了vuejs后，就节省了手动的修改DOM节点这一步骤。在vuejs里，通过【Directives】指令对DOM元素做一层封装，只需要修改数据，数据发生变化，通过【Directives】指令去修改对应的DOM，数据驱动DOM的变化，所以说DOM是数据的一种自然映射。vuejs还会对视图进行监听，当vuejs监听到视图DOM发生变化时，从而改变数据，这样就实现了数据的双向数据绑定。
    - 数据响应原理
    vuejs是如何实现的双向数据绑定呢？
    ![avatar](vue1.png)
    数据【model】改变是如何驱动视图【view】自动更新的
    图例解说：有一份数据(a.b),在一个vue实例化的过程中，会给a.b这份数据通过es5的Object.defineProperty方法添加一个getter和setter，同时，vuejs会对模版做编译，解析生成一个指令对象（这里就是一个v-text指令），每个指令对象都会关联一个watcher,当我们对指令对应的表达式a.b做求值的时候，就会触发它的getter，然后把依赖升级到watcher里面，当a.b的值发生改变的时候，会触发它的setter，同时也会通知到watcher，然后watcher再次对a.b求值，计算对比新旧值，当发现值改变了，watcher就会通知指令【Directive】,由于指令是对DOM的封装，所以会调用原生DOM的方法对视图进行更新，这样就完成了一个数据改变到驱动视图自动更新的一个过程。
* 组件化
    + 扩展HTML元素，封装可重用的代码
    + 组件设计原则:
    <ol>
    <li>页面上每个独立的可视／可交互区域视为一个组件</li>
    <li>每个组件对应一个工程目录，组件所需要的各种资源在这个目录下就近维护（前端工程化思想）</li>
    <li>页面不过是组件的容器，组件可以嵌套自由组合形成完整的页面</li>
    </ol>

## vue-cli介绍
   vue-cli是vue的脚手架工具，通过脚手架可以编写基础的代码
   ![avatar](vue4.png)
   如上图所示，vue-cli可以帮助我们搞定目录结构、本地调试、代码部署、热加载、单元测试等工作。
* 全局安装vue-cli并使用
   ```
   sudo npm install -g vue-cli
   vue init <template-name> <project-name>
   #例如:vue init webpack my-project
   ```
    其中，<template-name>是模板名称，分为三类，分别是通常用的官方模版（webpack/webpack-simple/browserify/browserify-simple/simple）、自定义模板（vue init username/repo my-project）、本地模板（vue init ~/fs/path/to-custom-template my-project）。无论是官方模板，还是自定义模板，都是从github的repo进行安装的，比如webpack模板，github相关仓库的template目录下的代码，就是执行相关命令最终生成的脚手架代码。自定义模板，只需要参考相关写法就可以了。
* 初始化一个项目
  ```bash
    npm init webpack earth_book
    cd earth_book
    sudo npm install
    npm run dev
  ```
* 脚手架生成文件介绍
    + build/config目录
    这两个文件夹里的文件都是和webpack配置相关的
    + node_modules目录
    这个文件夹里的文件都是通过npm install 安装的依赖代码库
    + src目录
    存放项目源码，我们开发所有的代码都放在src目录下
    + static目录
    存放一些第三方的静态资源
    .gitkeep文件的作用是，当static文件夹为空，也可以把代码提交到git仓库里，因为一般创建一个空目录，.git文件会忽略这个空目录，不会提交到仓库里。
    + .babelrc
    ```bash
    {
        "presets":["es2015","stage-2"],#预设，babel编译预先要安装的一些插件
        "plugins":["transform-runtime"],
        "comments":false #转换后代码不生成注释
    }
    ```
    babel的相关配置，开发使用的是es6的语法，把es6通过babel编译为es5，以适配一些不支持es6语法的浏览器。
    + .editorconfig
    编辑器的配置
    + .eslintignore
    忽略语法检查的目录文件
    + .eslintrc.js
    eslint的配置文件
    + package.json
    通过scripts配置一些脚本命令
    + index.html
    入口文件，项目的css和js会被动态的插入到该页面
    body标签里的app标签不是原生的html标签，而是vue的一个组件。页面的入口js是main.js，在该文件中，实例一个vue的实例，其中el就是挂载点，components就是注册了一个app组件。
