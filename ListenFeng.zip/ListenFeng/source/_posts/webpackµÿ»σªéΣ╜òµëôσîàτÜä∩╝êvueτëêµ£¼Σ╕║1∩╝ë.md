---
title: webpack是如何打包的（vue版本为1）
date: 2018-09-10 17:27:30
tags:
---
官网：https://webpack.github.io/
通过vue-cli生成脚手架，通过npm run dev运行，分析webpack是如何进行编译的
在package.json的script配置中，可以知道，执行<code>npm run dev</code>就相当于执行<code>node build/dev-server.js</code>，即运行build目录下的dev-server.js这个文件

```bash
#package.json
{
    "scripts":{
        "dev":"node build/dev-server.js",
        "build":"node build/build.js",
        "test":""
    }
}
```
配置详解：

<a href="#dev-server" target="_blank"><code><font color="#409EFF">build/dev-server.js</font></code></a>


<a href="#webpack_dev_conf" target="_blank"><code><font color="#409EFF">build/webpack.dev.conf.js</font></code></a>

<a href="#webpack_prod_conf" target="_blank"><code><font color="#409EFF">build/webpack.prod.conf.js</font></code></a>

<a href="#webpack_base_conf" target="_blank"><code><font color="#409EFF">build/webpack.base.conf.js</font></code></a>

<a href="#assetsPath" target="_blank"><code><font color="#409EFF">build/utils</font></code></a>

<a href="#config" target="_blank"><code><font color="#409EFF">config/index.js</font></code></a>

<a href="#dev_env" target="_blank"><code><font color="#409EFF">config/dev.env.js</font></code></a>

<a href="#prod_env" target="_blank"><code><font color="#409EFF">config/prod.env.js</font></code></a>

<!--more-->

## <span id = "dev-server">build/dev-server.js文件</span>
```bash
#依赖
var path = require('path') #nodejs提供的操作文件、路径的一些方法的api

#nodejs框架，这里用来启动一个web server
var express = require('express')

#nodejs提供的webpack API核心编译工具；也可以使用全局安装webpack的方式，然后使用全局命令进行webpack编译
var webpack = require('webpack')

#配置文件，目录为config/index.js
var config = require('../config')

# http协议代理的中间件，可以代理和转化一些API
var proxyMiddleware = require('http-proxy-middleware')

#webpack相关的一些配置，根据环境不同，选择不同的开发环境配置和线上环境配置
var webpackConfig = process.env.NODE_ENV === 'testing' ? require('./webpack.prod.conf') : require('./webpack.dev.conf')
```

## <span id = "config">config/index.js</span>
对运行时和开发时的一些配置
```bash
module.exports = {
    build: {
        assetsRoot: path.resolve(__dirname, '../dist'), # 相当于在当前目录下创建一个dist目录，作为输出的目录
        assetsPublicPath: '/',
    }
}
```

## <span id = "webpack_dev_conf">build/webpack.dev.conf.js</span>
开发环境的一些webpack的配置
```bash
#依赖
const utils = require('./utils') #一些工具方法
const webpack = require('webpack')
const config = require('../config')
const merge = require('webpack-merge') #用来合并配置文件用的
const baseWebpackConfig = require('./webpack.base.conf') # webpack的一个配置文件，被开发时的webpack配置文件和运行时的webpack文件共享
const HtmlWebpackPlugin = require('html-webpack-plugin') # webpack提供的操作html的一个插件

# 下面代码，把entry添加里一个'./build/dev-client'入口文件，把entry变成里一个数组。作用是启动了一些hot-reload的相关代码
Object.keys(baseWebpackConfig.entry).forEach(function(name){
    baseWebpackConfig.entry[name] = ['./build/dev-client'].concat(baseWebpackConfig.entry[name])
})

# 通过merge方法把baseWebpackConfig和后面的配置合并
const devWebpackConfig = merge(baseWebpackConfig, {
    module: {
        # 对独立的css文件配置相应的loader进行编译
        rules: utils.styleLoaders({ sourceMap: config.dev.cssSourceMap, usePostCSS: true })
    },
    # 方便开发时做源码调试用的
    devtool: config.dev.devtool,
    # 定义了一些插件
    plugins: [
        # 这个插件的作用是把源码中的'process.env'字符串替换成{NODE_ENV:'"development"'}
        new webpack.DefinePlugin({
          'process.env': require('../config/dev.env')
        }),
        # 热加载的一个插件
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
          filename: 'index.html', # 指定编译后的文件名
          template: 'index.html', # 指定要处理的模版
          inject: true # 表示打包的一些js/css的路径会自动添加到html文件中
        }),
        new CopyWebpackPlugin([
          {
            from: path.resolve(__dirname, '../static'),
            to: config.dev.assetsSubDirectory,
            ignore: ['.*']
          }
        ])
    ]
})
```

## <span id = "webpack_prod_conf">build/webpack.prod.conf.js</span>
线上环境的一些webpack的配置

## <span id = "webpack_base_conf">build/webpack.base.conf.js</span>
<a href="#assetsPath" target="_blank">utils.assetsPath</a>
<a href="#cssLoaders" target="_blank">utils.cssLoaders</a>
```bash
#依赖
var projectRoot = path.resolve(__dirname,'../') #定义当前项目的一个根目录，即build目录为根目录
#webpack的一些基本配置
module.exports = {
    entry: {
        app: './src/main.js' #入口文件配置
    },
    output: { # 输出的配置
        path: config.build.assetsRoot, # 输出的文件路径，对应config配置的{assetsRoot: path.resolve(__dirname, '../dist')}
        filename: '[name].js', # 输出的文件的名称，[name]对应的是entry里的key，所以打包输出的最终文件叫app.js
        publicPath: process.env.NODE_ENV === 'production'
                    ? config.build.assetsPublicPath
                    : config.dev.assetsPublicPath # 请求的静态资源绝对路径，根据环境不同，分别对应config配置文件的不同的值
    },
    resolve: { # resolve相关的配置，都是在代码中通过require或者es6的import引入的模块的一些相关配置
        extensions: ['.js', '.vue', '.json'], # 表示在require模块时自动补全后缀，所以在代码中可以省略后缀名
        alias: {
          'vue$': 'vue/dist/vue.esm.js',
          '@': resolve('src'),
        }, # 别名，通过使用别名，缩短路径的长度
        fallback:[path.join(__dirname,'../node_modules')]
    },
    module:{ # preLoaders和loaders都是表示对某一类型的文件，使用不同的loader去处理，webpack的编译阶段，就是使用不同的loader对不同的文件做编译，原理就是扫描当前的工程目录，根据后缀去匹配不同的文件，文件内容作为输入通过loader作处理输出新的文件内容。不同的是，preLoaders会在loaders之前做处理
        preLoaders:[ # 此处配置表示，.vue/.js的文件使用eslintLoader做处理。include表示只检查该目录下的一些文件，只对该目录下的文件做编译；exclude表示排除这些目录。比如下述配置表示只对node_modules目录下的.js文件做eslint检查，而不需要做babel编译
            {
                test:/\.vue$/,
                loader:'eslint',
                include:projectRoot,
                exclude:/node_modules/
            },
            {
                test:/\.js$/,
                loader:'eslint',
                include:projectRoot,
                exclude:/node_modules/
            }
        ],
        loaders:[ # 这里的配置表明，.js文件会使用babelLoader做处理
            {
                test:/\.vue$/,
                loader:'vue'
            },
            {
                test:/\.js$/,
                loader:'babel',
                include:projectRoot,
                exclude:/node_modules/
            },
            {
                test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
                loader: 'url-loader',
                options: {
                  limit: 10000, # 表示当图片的大小小于10kb的时候，该图片会编译为一个base64的字符串打包到编译后的js文件里，而超过10kb的大小，则会单独生成一个文件，文件名的规则根据utils.assetsPath最终得到【"static/img/文件名称.文件名称生成的7位的hash串.扩展名"】
                  name: utils.assetsPath('img/[name].[hash:7].[ext]')
                }
            },
            { # 字体文件的loader配置，规则同图片文件
                test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
                loader: 'url-loader',
                options: {
                  limit: 10000,
                  name: utils.assetsPath('fonts/[name].[hash:7].[ext]')
                }
            }
        ]
    },
    eslint:{ # eslint检查到语法错误时，会友好的提示错误信息，并提供一个es6规则的官网链接
        formatter:require('eslint-friendly-formatter')
    },
    vue:{# 关于vue文件中所有css的loader的配置
        loaders:utils.cssLoaders()
    }
}
```

## <span id = "utils">build/utils.js</span>
```bash
# 依赖
const path = require('path')
const config = require('../config')
```
<span id = "assetsPath">utils.assetsPath</span>
```bash
exports.assetsPath = function (_path) {
  const assetsSubDirectory = process.env.NODE_ENV === 'production'
    ? config.build.assetsSubDirectory
    : config.dev.assetsSubDirectory

  return path.posix.join(assetsSubDirectory, _path)
}
```
<span id = "cssLoaders">utils.cssLoaders</span>
```bash
# 所有css相关的loader都在这个方法里配置
exports.cssLoaders = function (options) {
  options = options || {}

  const cssLoader = {
    loader: 'css-loader',
    options: {
      sourceMap: options.sourceMap
    }
  }

  const postcssLoader = {
    loader: 'postcss-loader',
    options: {
      sourceMap: options.sourceMap
    }
  }

  // generate loader string to be used with extract text plugin
  function generateLoaders (loader, loaderOptions) {
    const loaders = options.usePostCSS ? [cssLoader, postcssLoader] : [cssLoader]

    if (loader) {
      loaders.push({
        loader: loader + '-loader',
        options: Object.assign({}, loaderOptions, {
          sourceMap: options.sourceMap
        })
      })
    }

    // Extract CSS when that option is specified
    // (which is the case during production build)
    if (options.extract) {
      return ExtractTextPlugin.extract({
        use: loaders,
        fallback: 'vue-style-loader'
      })
    } else {
      return ['vue-style-loader'].concat(loaders)
    }
  }

  // https://vue-loader.vuejs.org/en/configurations/extract-css.html
  return { # 返回一个各种css相关预处理器对应的loader的对象
    css: generateLoaders(),
    postcss: generateLoaders(),
    less: generateLoaders('less'),
    sass: generateLoaders('sass', { indentedSyntax: true }),
    scss: generateLoaders('sass'),
    stylus: generateLoaders('stylus'),
    styl: generateLoaders('stylus')
  }
}
```

<span id = "styleLoaders">utils.styleLoaders</span>
```bash
exports.styleLoaders = function (options) {
  const output = []
  const loaders = exports.cssLoaders(options)

  for (const extension in loaders) {
    const loader = loaders[extension]
    output.push({
      test: new RegExp('\\.' + extension + '$'),
      use: loader
    })
  }

  return output
}
```

## <span id = "dev_env">config/dev.env.js</span>

```bash
'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"'
})
```

## <span id = "prod_env">config/prod.env.js</span>

```bash
'use strict'
module.exports = {
  NODE_ENV: '"production"'
}
```
