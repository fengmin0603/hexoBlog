---
title: 利用github pages搭建个人博客
date: 2018-09-06 14:40:15
tags:
---
使用github pages服务搭建博客的好处有：

<ol>
<li>全是静态文件，访问速度快；</li>
<li>免费方便，不用花一分钱就可以搭建一个自由的个人博客，不需要服务器不需要后台；</li>
<li>可以随意绑定自己的域名；</li>
<li>数据绝对安全，基于github的版本管理，想恢复到哪个历史版本都行；</li>
</ol>

<!--more-->

## 1. 准备工作
<ol>
<li>注册一个github账号</li>
<li>安装node.js、npm、git</li>
</ol>

## 2. 创建博客的github仓库
每一个github账户最多只能创建一个这样可以直接使用域名访问的仓库，仓库名字必须是：<code><font color="orange">username.github.io</font></code>，其中username是你的用户名；仓库创建成功可能不会立即生效，等半个消失即可。
仓库创建成功后，可以配置个性域名

## <span id = "jump">3. 配置SSH key</span>
让所使用的电脑拥有你的github权限，才可以往github上提交代码，使用ssh key来解决本地和服务器的连接问题。
 ``` bash
 $ cd ~/. ssh #检查本机已存在的ssh密钥
 ```
如果提示：No such file or directory 说明你是第一次使用git。
 ``` bash
 ssh-keygen -t rsa -C "邮件地址"
 ```
 然后连续3次回车，最终会生成一个文件在用户目录下，打开用户目录，找到.ssh\id_rsa.pub文件，记事本打开并复制里面的内容，打开你的github主页，进入个人设置 -> SSH and GPG keys -> New SSH key
 将刚复制的内容粘贴到key那里，title随便填，保存。

## 4. 使用hexo写博客
Hexo是一个简单、快速、强大的基于 Github Pages 的博客发布工具，支持Markdown格式，有众多优秀插件和主题。
官网： http://hexo.io；
官方主题：https://hexo.io/themes/
* mac安装hexo
    ```bash
    sudo npm install hexo-cli -g
    ```
* 初始化一个hexo博客并启动博客服务
    ```bash
    hexo init
    hexo g
    hexo s
    ```
 执行以上命令之后，hexo就会在public文件夹生成相关html文件，这些文件将来都是要提交到github去的
* 新建一篇博客
    ```
    hexo new "文章名称" #新建文章
    ```
    默认情况下，生成的博文目录会显示全部的文章内容，在合适的位置加上<!--more-->即可设置文章摘要的长度

## 文章资源文件夹
    对于那些想要更有规律地提供图片和其他资源以及想要将他们的资源分布在各个文章上的人来说，Hexo也提供了更组织化的方式来管理资源。这个稍微有些复杂但是管理资源非常方便的功能可以通过将 config.yml 文件中的 post_asset_folder 选项设为 true 来打开。
    本地server成功，部署到GitHub上之后不能显示主题样式
        更改一下_config.yml文件，其中url和root属性设置为要访问的项目地址，root下面应该设置成【/项目名】。静态资源的引用路径使用相对路径
## 上传到github
几个必要条件：
* <a href="#jump" target="_self">ssh key配置好</a>
* 配置_config.yml中有关deploy的部分：
    ```
    deploy:
      type: git
      repository: git@github.com:ListenFeng/ListenFeng.github.io.git
      branch: master
    ```
* 安装一个插件
    ```
    npm install hexo-deployer-git --save
    ```
    执行命令
    ```
    hexo d
    ```
    就会将本次有改动的代码全部提交，没有改动的不会
    
